#!/bin/sh
rm -rf release CMakeFiles
rm -rf Makefile cmake_install.cmake CMakeCache.txt
